/*******************************************************************************
 * Name        : contacts.c
 * Author      : Ciaran Walsh, Lynsey Overturf, Ashley Qian
 * Description : Solution to HackerRank -> Data Structures -> Trie -> Contacts
 *               https://www.hackerrank.com/challenges/contacts/problem
 ******************************************************************************/
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALPHABET_LENGTH    26
#define OPERATION_BUF_SIZE  7 /* Large enough to cover the word 'search' and '\0' */
#define NAME_BUF_SIZE      22

/* Basic trie node */
typedef struct node {
    /* The number of words in the trie that contain the prefix down to and
       including the current letter. */
    int prefix_count;
    /* Allocate +1 for the the pointer to the end-of-string marker. Needed
       for the search feature. */
    struct node *children[ALPHABET_LENGTH + 1];
} trie_node;

/* Corresponds to operation strings. Improves readability. */
typedef enum {
    OP_ADD,
    OP_FIND,
    OP_SEARCH,
    OP_UNKNOWN
} op_type;

/*
 * A shared sentinel marks the end of every stored word. Since the program
 * never dereferences this node, one sentinel avoids an allocation per word.
 */
static trie_node end_marker;

/* Allocate a zero-initialized trie node. */
static trie_node *create_node(void)
{
    return calloc(1, sizeof(trie_node));
}

/* Mapping operation strings to enum. */
static op_type parse_op(const char *op_str)
{
    if (strcmp(op_str, "add") == 0) {
        return OP_ADD;
    }
    if (strcmp(op_str, "find") == 0) {
        return OP_FIND;
    }
    if (strcmp(op_str, "search") == 0) {
        return OP_SEARCH;
    }
    return OP_UNKNOWN;
}

/*
 * Helper function for find() and search().
 * Go down the trie following word without modifying nodes. Returns the node reached
 * after consuming the last letter, or NULL if the path does not exist.
 */
static const trie_node *descend(const trie_node *current, const char *word)
{
    while (*word != '\0') {
        int index = *word - 'a';

        if (current->children[index] == NULL) {
            return NULL;
        }

        current = current->children[index];
        word++;
    }

    return current;
}

/*
 * Add word to the trie. Each add operation increases the prefix counts,
 * including when the same word is added more than once. Returns false only
 * if a node allocation fails.
 */
static bool add(trie_node *current, const char *word)
{
    while (*word != '\0') {
        int index = *word - 'a';

        if (current->children[index] == NULL) {
            current->children[index] = create_node();
            if (current->children[index] == NULL) {
                return false;
            }
        }

        current = current->children[index];
        current->prefix_count++;
        word++;
    }

    current->children[ALPHABET_LENGTH] = &end_marker;
    return true;
}

/* Return the number of stored names that begin with prefix. */
static int find(const trie_node *root, const char *prefix)
{
    const trie_node *node = descend(root, prefix);
    return node ? node->prefix_count : 0;
}

/* Return true only when the complete word, rather than just a prefix, exists. */
static bool search(const trie_node *root, const char *word)
{
    const trie_node *node = descend(root, word);
    return node && node->children[ALPHABET_LENGTH];
}

/* Recursively release all allocated letter nodes, but not the shared marker. */
static void free_trie(trie_node *root)
{
    if (root == NULL) {
        return;
    }

    /* The shared static sentinel lives in BSS and does not need to be freed */
    for (int i = 0; i < ALPHABET_LENGTH; i++) {
        free_trie(root->children[i]);
    }
    free(root);
}

int main(void)
{
    int op_count;
    char op[OPERATION_BUF_SIZE];
    char name[NAME_BUF_SIZE];
    trie_node *root = create_node();

    /* Error handling: calloc failed */
    if (root == NULL) {
        return EXIT_FAILURE;
    }

    /* Error handling: scanf failed */
    if (scanf("%d", &op_count) != 1) {
        free_trie(root);
        return EXIT_FAILURE;
    }

    for (int i = 0; i < op_count; i++) {
        /* Error handling: scanf failed */
        if (scanf("%6s %21s", op, name) != 2) {
            free_trie(root);
            return EXIT_FAILURE;
        }

        switch (parse_op(op)) {
            case OP_ADD:
                if (!add(root, name)) {
                    free_trie(root);
                    return EXIT_FAILURE;
                }
                break;
            case OP_FIND:
                printf("%d\n", find(root, name));
                break;
            case OP_SEARCH:
                puts(search(root, name) ? "yes" : "no");
                break;
            case OP_UNKNOWN:
                break;
        }
    }

    free_trie(root);
    return EXIT_SUCCESS;
}
